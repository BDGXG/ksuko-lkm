.class Lwww/wslw/cn/LokiBridge$6;
.super Ljava/lang/Object;
.source "LokiBridge.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lwww/wslw/cn/LokiBridge;->exitApp()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lwww/wslw/cn/LokiBridge;


# direct methods
.method constructor <init>(Lwww/wslw/cn/LokiBridge;)V
    .locals 0

    .line 350
    iput-object p1, p0, Lwww/wslw/cn/LokiBridge$6;->this$0:Lwww/wslw/cn/LokiBridge;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    .line 353
    :try_start_0
    iget-object v0, p0, Lwww/wslw/cn/LokiBridge$6;->this$0:Lwww/wslw/cn/LokiBridge;

    invoke-static {v0}, Lwww/wslw/cn/LokiBridge;->access$000(Lwww/wslw/cn/LokiBridge;)Landroid/app/Activity;

    move-result-object v0

    invoke-virtual {v0}, Landroid/app/Activity;->finishAffinity()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    const/4 v0, 0x0

    .line 356
    :try_start_1
    invoke-static {v0}, Ljava/lang/System;->exit(I)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :catchall_1
    return-void
.end method
