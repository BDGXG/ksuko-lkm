.class Lwww/wslw/cn/LokiBridge$2;
.super Ljava/lang/Object;
.source "LokiBridge.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lwww/wslw/cn/LokiBridge;->setClipboard(Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lwww/wslw/cn/LokiBridge;

.field final synthetic val$text:Ljava/lang/String;


# direct methods
.method constructor <init>(Lwww/wslw/cn/LokiBridge;Ljava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 257
    iput-object p1, p0, Lwww/wslw/cn/LokiBridge$2;->this$0:Lwww/wslw/cn/LokiBridge;

    iput-object p2, p0, Lwww/wslw/cn/LokiBridge$2;->val$text:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 260
    :try_start_0
    iget-object v0, p0, Lwww/wslw/cn/LokiBridge$2;->this$0:Lwww/wslw/cn/LokiBridge;

    .line 261
    invoke-static {v0}, Lwww/wslw/cn/LokiBridge;->access$000(Lwww/wslw/cn/LokiBridge;)Landroid/app/Activity;

    move-result-object v0

    const-string v1, "clipboard"

    invoke-virtual {v0, v1}, Landroid/app/Activity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/ClipboardManager;

    .line 262
    const-string v1, "loki"

    iget-object v2, p0, Lwww/wslw/cn/LokiBridge$2;->val$text:Ljava/lang/String;

    invoke-static {v1, v2}, Landroid/content/ClipData;->newPlainText(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/ClipboardManager;->setPrimaryClip(Landroid/content/ClipData;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    return-void
.end method
