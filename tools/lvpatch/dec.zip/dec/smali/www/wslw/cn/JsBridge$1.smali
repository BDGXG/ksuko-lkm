.class Lwww/wslw/cn/JsBridge$1;
.super Ljava/lang/Object;
.source "JsBridge.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lwww/wslw/cn/JsBridge;->copy(Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lwww/wslw/cn/JsBridge;

.field final synthetic val$text:Ljava/lang/String;


# direct methods
.method constructor <init>(Lwww/wslw/cn/JsBridge;Ljava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 89
    iput-object p1, p0, Lwww/wslw/cn/JsBridge$1;->this$0:Lwww/wslw/cn/JsBridge;

    iput-object p2, p0, Lwww/wslw/cn/JsBridge$1;->val$text:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const-string v0, "\u5df2\u590d\u5236 "

    const/4 v1, 0x0

    .line 92
    :try_start_0
    iget-object v2, p0, Lwww/wslw/cn/JsBridge$1;->this$0:Lwww/wslw/cn/JsBridge;

    .line 93
    invoke-static {v2}, Lwww/wslw/cn/JsBridge;->access$000(Lwww/wslw/cn/JsBridge;)Lwww/wslw/cn/MainActivity;

    move-result-object v2

    const-string v3, "clipboard"

    invoke-virtual {v2, v3}, Lwww/wslw/cn/MainActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/content/ClipboardManager;

    if-eqz v2, :cond_0

    .line 95
    const-string v3, "hideguard"

    iget-object v4, p0, Lwww/wslw/cn/JsBridge$1;->val$text:Ljava/lang/String;

    invoke-static {v3, v4}, Landroid/content/ClipData;->newPlainText(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;

    move-result-object v3

    invoke-virtual {v2, v3}, Landroid/content/ClipboardManager;->setPrimaryClip(Landroid/content/ClipData;)V

    .line 96
    iget-object v2, p0, Lwww/wslw/cn/JsBridge$1;->this$0:Lwww/wslw/cn/JsBridge;

    invoke-static {v2}, Lwww/wslw/cn/JsBridge;->access$000(Lwww/wslw/cn/JsBridge;)Lwww/wslw/cn/MainActivity;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v0, p0, Lwww/wslw/cn/JsBridge$1;->val$text:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, " \u5b57\u7b26"

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    .line 97
    invoke-virtual {v0}, Landroid/widget/Toast;->show()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    .line 100
    iget-object v2, p0, Lwww/wslw/cn/JsBridge$1;->this$0:Lwww/wslw/cn/JsBridge;

    invoke-static {v2}, Lwww/wslw/cn/JsBridge;->access$000(Lwww/wslw/cn/JsBridge;)Lwww/wslw/cn/MainActivity;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "\u590d\u5236\u5931\u8d25\uff1a"

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    :cond_0
    :goto_0
    return-void
.end method
