.class public Lwww/wslw/cn/JsBridge;
.super Ljava/lang/Object;
.source "JsBridge.java"


# instance fields
.field private final act:Lwww/wslw/cn/MainActivity;


# direct methods
.method constructor <init>(Lwww/wslw/cn/MainActivity;)V
    .locals 0

    .line 33
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 34
    iput-object p1, p0, Lwww/wslw/cn/JsBridge;->act:Lwww/wslw/cn/MainActivity;

    return-void
.end method

.method static synthetic access$000(Lwww/wslw/cn/JsBridge;)Lwww/wslw/cn/MainActivity;
    .locals 0

    .line 29
    iget-object p0, p0, Lwww/wslw/cn/JsBridge;->act:Lwww/wslw/cn/MainActivity;

    return-object p0
.end method

.method private iconB64(Landroid/content/pm/PackageManager;Landroid/content/pm/ApplicationInfo;I)Ljava/lang/String;
    .locals 4

    const-string v0, "data:image/png;base64,"

    const/4 v1, 0x0

    .line 68
    :try_start_0
    invoke-virtual {p2, p1}, Landroid/content/pm/ApplicationInfo;->loadIcon(Landroid/content/pm/PackageManager;)Landroid/graphics/drawable/Drawable;

    move-result-object p1

    if-nez p1, :cond_0

    return-object v1

    .line 70
    :cond_0
    sget-object p2, Landroid/graphics/Bitmap$Config;->ARGB_8888:Landroid/graphics/Bitmap$Config;

    invoke-static {p3, p3, p2}, Landroid/graphics/Bitmap;->createBitmap(IILandroid/graphics/Bitmap$Config;)Landroid/graphics/Bitmap;

    move-result-object p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    .line 71
    :try_start_1
    new-instance v2, Landroid/graphics/Canvas;

    invoke-direct {v2, p2}, Landroid/graphics/Canvas;-><init>(Landroid/graphics/Bitmap;)V

    const/4 v3, 0x0

    .line 72
    invoke-virtual {p1, v3, v3, p3, p3}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 73
    invoke-virtual {p1, v2}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    .line 74
    new-instance p1, Ljava/io/ByteArrayOutputStream;

    invoke-direct {p1}, Ljava/io/ByteArrayOutputStream;-><init>()V

    .line 75
    sget-object p3, Landroid/graphics/Bitmap$CompressFormat;->PNG:Landroid/graphics/Bitmap$CompressFormat;

    const/16 v2, 0x5a

    invoke-virtual {p2, p3, v2, p1}, Landroid/graphics/Bitmap;->compress(Landroid/graphics/Bitmap$CompressFormat;ILjava/io/OutputStream;)Z

    .line 76
    invoke-virtual {p1}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p1

    .line 77
    new-instance p3, Ljava/lang/StringBuilder;

    invoke-direct {p3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v0, 0x2

    invoke-static {p1, v0}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    if-eqz p2, :cond_1

    .line 81
    invoke-virtual {p2}, Landroid/graphics/Bitmap;->recycle()V

    :cond_1
    return-object p1

    :catchall_0
    nop

    goto :goto_0

    :catchall_1
    nop

    move-object p2, v1

    :goto_0
    if-eqz p2, :cond_2

    invoke-virtual {p2}, Landroid/graphics/Bitmap;->recycle()V

    :cond_2
    return-object v1
.end method


# virtual methods
.method public copy(Ljava/lang/String;)V
    .locals 2
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    if-nez p1, :cond_0

    return-void

    .line 89
    :cond_0
    iget-object v0, p0, Lwww/wslw/cn/JsBridge;->act:Lwww/wslw/cn/MainActivity;

    new-instance v1, Lwww/wslw/cn/JsBridge$1;

    invoke-direct {v1, p0, p1}, Lwww/wslw/cn/JsBridge$1;-><init>(Lwww/wslw/cn/JsBridge;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Lwww/wslw/cn/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method

.method public getApps()Ljava/lang/String;
    .locals 10
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 40
    new-instance v0, Lorg/json/JSONArray;

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    .line 42
    :try_start_0
    iget-object v1, p0, Lwww/wslw/cn/JsBridge;->act:Lwww/wslw/cn/MainActivity;

    invoke-virtual {v1}, Lwww/wslw/cn/MainActivity;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/4 v2, 0x0

    .line 43
    invoke-virtual {v1, v2}, Landroid/content/pm/PackageManager;->getInstalledApplications(I)Ljava/util/List;

    move-result-object v3

    const/4 v4, 0x0

    .line 44
    :goto_0
    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v5

    if-ge v4, v5, :cond_2

    .line 45
    invoke-interface {v3, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/content/pm/ApplicationInfo;

    .line 46
    iget v6, v5, Landroid/content/pm/ApplicationInfo;->flags:I

    const/4 v7, 0x1

    and-int/2addr v6, v7

    if-eqz v6, :cond_0

    goto :goto_1

    :cond_0
    const/4 v7, 0x0

    .line 47
    :goto_1
    new-instance v6, Lorg/json/JSONObject;

    invoke-direct {v6}, Lorg/json/JSONObject;-><init>()V

    .line 48
    const-string v8, "pkg"

    iget-object v9, v5, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    invoke-virtual {v6, v8, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 49
    const-string v8, "uid"

    iget v9, v5, Landroid/content/pm/ApplicationInfo;->uid:I

    invoke-virtual {v6, v8, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    .line 50
    const-string v8, "label"

    invoke-virtual {v1, v5}, Landroid/content/pm/PackageManager;->getApplicationLabel(Landroid/content/pm/ApplicationInfo;)Ljava/lang/CharSequence;

    move-result-object v9

    invoke-static {v9}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v6, v8, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 51
    const-string v8, "system"

    invoke-virtual {v6, v8, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    if-nez v7, :cond_1

    const/16 v7, 0x60

    .line 53
    invoke-direct {p0, v1, v5, v7}, Lwww/wslw/cn/JsBridge;->iconB64(Landroid/content/pm/PackageManager;Landroid/content/pm/ApplicationInfo;I)Ljava/lang/String;

    move-result-object v5

    if-eqz v5, :cond_1

    .line 54
    const-string v7, "icon"

    invoke-virtual {v6, v7, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 56
    :cond_1
    invoke-virtual {v0, v6}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    .line 61
    :catchall_0
    :cond_2
    invoke-virtual {v0}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public paste()Ljava/lang/String;
    .locals 5
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 109
    const-string v0, ""

    filled-new-array {v0}, [Ljava/lang/String;

    move-result-object v0

    .line 110
    new-instance v1, Ljava/util/concurrent/CountDownLatch;

    const/4 v2, 0x1

    invoke-direct {v1, v2}, Ljava/util/concurrent/CountDownLatch;-><init>(I)V

    .line 111
    iget-object v2, p0, Lwww/wslw/cn/JsBridge;->act:Lwww/wslw/cn/MainActivity;

    new-instance v3, Lwww/wslw/cn/JsBridge$2;

    invoke-direct {v3, p0, v0, v1}, Lwww/wslw/cn/JsBridge$2;-><init>(Lwww/wslw/cn/JsBridge;[Ljava/lang/String;Ljava/util/concurrent/CountDownLatch;)V

    invoke-virtual {v2, v3}, Lwww/wslw/cn/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    .line 129
    :try_start_0
    sget-object v2, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const-wide/16 v3, 0x2

    invoke-virtual {v1, v3, v4, v2}, Ljava/util/concurrent/CountDownLatch;->await(JLjava/util/concurrent/TimeUnit;)Z
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    goto :goto_0

    .line 131
    :catch_0
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Thread;->interrupt()V

    :goto_0
    const/4 v1, 0x0

    .line 133
    aget-object v0, v0, v1

    return-object v0
.end method

.method public switchTab(I)V
    .locals 1
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 149
    iget-object v0, p0, Lwww/wslw/cn/JsBridge;->act:Lwww/wslw/cn/MainActivity;

    invoke-virtual {v0, p1}, Lwww/wslw/cn/MainActivity;->switchTabFromJs(I)V

    return-void
.end method

.method public toast(Ljava/lang/String;)V
    .locals 2
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    if-nez p1, :cond_0

    return-void

    .line 139
    :cond_0
    iget-object v0, p0, Lwww/wslw/cn/JsBridge;->act:Lwww/wslw/cn/MainActivity;

    new-instance v1, Lwww/wslw/cn/JsBridge$3;

    invoke-direct {v1, p0, p1}, Lwww/wslw/cn/JsBridge$3;-><init>(Lwww/wslw/cn/JsBridge;Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Lwww/wslw/cn/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method

.method public version()Ljava/lang/String;
    .locals 1
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation

    .line 154
    const-string v0, "2.0"

    return-object v0
.end method
