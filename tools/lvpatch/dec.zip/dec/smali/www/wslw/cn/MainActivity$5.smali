.class Lwww/wslw/cn/MainActivity$5;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/webkit/ValueCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lwww/wslw/cn/MainActivity;->onBackPressed()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroid/webkit/ValueCallback<",
        "Ljava/lang/String;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic this$0:Lwww/wslw/cn/MainActivity;

.field final synthetic val$w:Landroid/webkit/WebView;


# direct methods
.method constructor <init>(Lwww/wslw/cn/MainActivity;Landroid/webkit/WebView;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 300
    iput-object p1, p0, Lwww/wslw/cn/MainActivity$5;->this$0:Lwww/wslw/cn/MainActivity;

    iput-object p2, p0, Lwww/wslw/cn/MainActivity$5;->val$w:Landroid/webkit/WebView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic onReceiveValue(Ljava/lang/Object;)V
    .locals 0

    .line 300
    check-cast p1, Ljava/lang/String;

    invoke-virtual {p0, p1}, Lwww/wslw/cn/MainActivity$5;->onReceiveValue(Ljava/lang/String;)V

    return-void
.end method

.method public onReceiveValue(Ljava/lang/String;)V
    .locals 1

    if-nez p1, :cond_0

    .line 302
    const-string p1, ""

    .line 303
    :cond_0
    const-string v0, "handled"

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_1

    return-void

    .line 304
    :cond_1
    const-string v0, "pass"

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_5

    const-string v0, "error"

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p1

    if-eqz p1, :cond_2

    goto :goto_0

    .line 309
    :cond_2
    iget-object p1, p0, Lwww/wslw/cn/MainActivity$5;->val$w:Landroid/webkit/WebView;

    invoke-virtual {p1}, Landroid/webkit/WebView;->canGoBack()Z

    move-result p1

    if-eqz p1, :cond_3

    iget-object p1, p0, Lwww/wslw/cn/MainActivity$5;->val$w:Landroid/webkit/WebView;

    invoke-virtual {p1}, Landroid/webkit/WebView;->goBack()V

    return-void

    .line 310
    :cond_3
    iget-object p1, p0, Lwww/wslw/cn/MainActivity$5;->this$0:Lwww/wslw/cn/MainActivity;

    invoke-static {p1}, Lwww/wslw/cn/MainActivity;->access$300(Lwww/wslw/cn/MainActivity;)I

    move-result p1

    if-eqz p1, :cond_4

    iget-object p1, p0, Lwww/wslw/cn/MainActivity$5;->this$0:Lwww/wslw/cn/MainActivity;

    const/4 v0, 0x0

    invoke-static {p1, v0}, Lwww/wslw/cn/MainActivity;->access$100(Lwww/wslw/cn/MainActivity;I)V

    return-void

    .line 311
    :cond_4
    iget-object p1, p0, Lwww/wslw/cn/MainActivity$5;->this$0:Lwww/wslw/cn/MainActivity;

    invoke-static {p1}, Lwww/wslw/cn/MainActivity;->access$200(Lwww/wslw/cn/MainActivity;)V

    return-void

    .line 305
    :cond_5
    :goto_0
    iget-object p1, p0, Lwww/wslw/cn/MainActivity$5;->this$0:Lwww/wslw/cn/MainActivity;

    invoke-static {p1}, Lwww/wslw/cn/MainActivity;->access$200(Lwww/wslw/cn/MainActivity;)V

    return-void
.end method
