.class public Lwww/wslw/cn/MainActivity;
.super Landroid/app/Activity;
.source "MainActivity.java"


# static fields
.field private static final BACK_EXIT_INTERVAL:J = 0x7d0L

.field private static final COLOR_ACCENT_HG:I = -0xcf2ea8

.field private static final COLOR_ACCENT_LA:I = -0xf57b01

.field private static final COLOR_BG:I = -0xf4f4f3

.field private static final COLOR_TAB_IDLE:I = -0x71716d

.field private static final COLOR_TAB_ON:I = -0x1

.field private static final URL_HIDE:Ljava/lang/String; = "http://127.0.0.1:16666/"

.field private static final URL_LAUNCHER:Ljava/lang/String; = "http://127.0.0.1:18888/"


# instance fields
.field private final accents:[I

.field private cur:I

.field private lastBackTime:J

.field private final tabBars:[Landroid/view/View;

.field private final tabLabels:[Landroid/widget/TextView;

.field private final webs:[Landroid/webkit/WebView;


# direct methods
.method public constructor <init>()V
    .locals 3

    .line 36
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v0, 0x3

    .line 47
    new-array v1, v0, [Landroid/webkit/WebView;

    iput-object v1, p0, Lwww/wslw/cn/MainActivity;->webs:[Landroid/webkit/WebView;

    .line 48
    new-array v1, v0, [Landroid/widget/TextView;

    iput-object v1, p0, Lwww/wslw/cn/MainActivity;->tabLabels:[Landroid/widget/TextView;

    .line 49
    new-array v0, v0, [Landroid/view/View;

    iput-object v0, p0, Lwww/wslw/cn/MainActivity;->tabBars:[Landroid/view/View;

    const v0, -0xf57b01

    const v1, -0xcf2ea8

    const v2, -0xcf2ea8

    .line 50
    filled-new-array {v0, v1, v2}, [I

    move-result-object v0

    iput-object v0, p0, Lwww/wslw/cn/MainActivity;->accents:[I

    const/4 v0, 0x0

    .line 52
    iput v0, p0, Lwww/wslw/cn/MainActivity;->cur:I

    const-wide/16 v0, 0x0

    .line 281
    iput-wide v0, p0, Lwww/wslw/cn/MainActivity;->lastBackTime:J

    return-void
.end method

.method static synthetic access$000(Lwww/wslw/cn/MainActivity;)V
    .locals 0

    .line 36
    invoke-direct {p0}, Lwww/wslw/cn/MainActivity;->applyHideBars()V

    return-void
.end method

.method static synthetic access$100(Lwww/wslw/cn/MainActivity;I)V
    .locals 0

    .line 36
    invoke-direct {p0, p1}, Lwww/wslw/cn/MainActivity;->select(I)V

    return-void
.end method

.method static synthetic access$200(Lwww/wslw/cn/MainActivity;)V
    .locals 0

    .line 36
    invoke-direct {p0}, Lwww/wslw/cn/MainActivity;->doExitWithConfirm()V

    return-void
.end method

.method static synthetic access$300(Lwww/wslw/cn/MainActivity;)I
    .locals 0

    .line 36
    iget p0, p0, Lwww/wslw/cn/MainActivity;->cur:I

    return p0
.end method

.method private applyHideBars()V
    .locals 9

    .line 143
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1e

    if-lt v0, v1, :cond_0

    const/4 v0, 0x1

    const/4 v1, 0x0

    .line 146
    :try_start_0
    const-class v2, Landroid/view/Window;

    const-string v3, "setDecorFitsSystemWindows"

    new-array v4, v0, [Ljava/lang/Class;

    sget-object v5, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    aput-object v5, v4, v1

    invoke-virtual {v2, v3, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    .line 147
    invoke-virtual {p0}, Lwww/wslw/cn/MainActivity;->getWindow()Landroid/view/Window;

    move-result-object v3

    new-array v4, v0, [Ljava/lang/Object;

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    aput-object v5, v4, v1

    invoke-virtual {v2, v3, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 150
    :catchall_0
    :try_start_1
    const-class v2, Landroid/view/Window;

    const-string v3, "getInsetsController"

    new-array v4, v1, [Ljava/lang/Class;

    invoke-virtual {v2, v3, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    invoke-virtual {p0}, Lwww/wslw/cn/MainActivity;->getWindow()Landroid/view/Window;

    move-result-object v3

    new-array v4, v1, [Ljava/lang/Object;

    invoke-virtual {v2, v3, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    if-eqz v2, :cond_0

    .line 152
    const-string v3, "android.view.WindowInsetsController"

    invoke-static {v3}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v3

    .line 153
    const-string v4, "android.view.WindowInsets$Type"

    invoke-static {v4}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v4

    .line 154
    const-string v5, "statusBars"

    new-array v6, v1, [Ljava/lang/Class;

    invoke-virtual {v4, v5, v6}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v5

    new-array v6, v1, [Ljava/lang/Object;

    const/4 v7, 0x0

    invoke-virtual {v5, v7, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    const-string v6, "navigationBars"

    new-array v8, v1, [Ljava/lang/Class;

    .line 155
    invoke-virtual {v4, v6, v8}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v4

    new-array v6, v1, [Ljava/lang/Object;

    invoke-virtual {v4, v7, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Integer;

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4

    or-int/2addr v4, v5

    .line 156
    const-string v5, "hide"

    new-array v6, v0, [Ljava/lang/Class;

    sget-object v8, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    aput-object v8, v6, v1

    invoke-virtual {v3, v5, v6}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v5

    new-array v6, v0, [Ljava/lang/Object;

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v6, v1

    invoke-virtual {v5, v2, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 157
    const-string v4, "BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE"

    invoke-virtual {v3, v4}, Ljava/lang/Class;->getField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v4

    invoke-virtual {v4, v7}, Ljava/lang/reflect/Field;->getInt(Ljava/lang/Object;)I

    move-result v4

    .line 158
    const-string v5, "setSystemBarsBehavior"

    new-array v6, v0, [Ljava/lang/Class;

    sget-object v7, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    aput-object v7, v6, v1

    invoke-virtual {v3, v5, v6}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v3

    new-array v0, v0, [Ljava/lang/Object;

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    aput-object v4, v0, v1

    invoke-virtual {v3, v2, v0}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    return-void

    .line 163
    :catchall_1
    :cond_0
    invoke-virtual {p0}, Lwww/wslw/cn/MainActivity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v0

    const/16 v1, 0x1706

    .line 164
    invoke-virtual {v0, v1}, Landroid/view/View;->setSystemUiVisibility(I)V

    return-void
.end method

.method private buildTab(Ljava/lang/String;I)Landroid/view/View;
    .locals 6

    .line 180
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    .line 181
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 182
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setGravity(I)V

    .line 183
    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v2, 0x0

    const/4 v3, -0x1

    const/high16 v4, 0x3f800000    # 1.0f

    invoke-direct {v1, v2, v3, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    .line 185
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 187
    new-instance v1, Landroid/widget/TextView;

    invoke-direct {v1, p0}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 188
    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 p1, 0x11

    .line 189
    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setGravity(I)V

    const/high16 p1, 0x41700000    # 15.0f

    const/4 v5, 0x2

    .line 190
    invoke-virtual {v1, v5, p1}, Landroid/widget/TextView;->setTextSize(IF)V

    .line 191
    sget-object p1, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    const p1, -0x71716d

    .line 192
    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setTextColor(I)V

    .line 193
    new-instance p1, Landroid/widget/LinearLayout$LayoutParams;

    invoke-direct {p1, v3, v2, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 195
    iget-object p1, p0, Lwww/wslw/cn/MainActivity;->tabLabels:[Landroid/widget/TextView;

    aput-object v1, p1, p2

    .line 197
    new-instance p1, Landroid/view/View;

    invoke-direct {p1, p0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    .line 198
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    .line 199
    invoke-direct {p0, v5}, Lwww/wslw/cn/MainActivity;->dp(I)I

    move-result v4

    invoke-direct {v2, v3, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 198
    invoke-virtual {p1, v2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 200
    iget-object v2, p0, Lwww/wslw/cn/MainActivity;->tabBars:[Landroid/view/View;

    aput-object p1, v2, p2

    .line 202
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 203
    invoke-virtual {v0, p1}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 204
    new-instance p1, Lwww/wslw/cn/MainActivity$3;

    invoke-direct {p1, p0, p2}, Lwww/wslw/cn/MainActivity$3;-><init>(Lwww/wslw/cn/MainActivity;I)V

    invoke-virtual {v0, p1}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-object v0
.end method

.method private buildWeb(Ljava/lang/String;)Landroid/webkit/WebView;
    .locals 4

    .line 214
    new-instance v0, Landroid/webkit/WebView;

    invoke-direct {v0, p0}, Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V

    .line 215
    new-instance v1, Landroid/widget/FrameLayout$LayoutParams;

    const/4 v2, -0x1

    invoke-direct {v1, v2, v2}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v0, v1}, Landroid/webkit/WebView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const v1, -0xf4f4f3

    .line 217
    invoke-virtual {v0, v1}, Landroid/webkit/WebView;->setBackgroundColor(I)V

    .line 219
    invoke-virtual {v0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v1

    const/4 v2, 0x1

    .line 220
    invoke-virtual {v1, v2}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V

    .line 221
    invoke-virtual {v1, v2}, Landroid/webkit/WebSettings;->setDomStorageEnabled(Z)V

    .line 222
    invoke-virtual {v1, v2}, Landroid/webkit/WebSettings;->setDatabaseEnabled(Z)V

    .line 223
    invoke-virtual {v1, v2}, Landroid/webkit/WebSettings;->setUseWideViewPort(Z)V

    .line 224
    invoke-virtual {v1, v2}, Landroid/webkit/WebSettings;->setLoadWithOverviewMode(Z)V

    const/4 v3, 0x0

    .line 225
    invoke-virtual {v1, v3}, Landroid/webkit/WebSettings;->setSupportZoom(Z)V

    .line 226
    invoke-virtual {v1, v3}, Landroid/webkit/WebSettings;->setBuiltInZoomControls(Z)V

    .line 227
    invoke-virtual {v1, v2}, Landroid/webkit/WebSettings;->setAllowFileAccess(Z)V

    .line 228
    invoke-virtual {v1, v2}, Landroid/webkit/WebSettings;->setJavaScriptCanOpenWindowsAutomatically(Z)V

    .line 229
    invoke-virtual {v1, v3}, Landroid/webkit/WebSettings;->setMediaPlaybackRequiresUserGesture(Z)V

    .line 232
    invoke-virtual {v1, v3}, Landroid/webkit/WebSettings;->setMixedContentMode(I)V

    .line 235
    new-instance v1, Landroid/webkit/WebViewClient;

    invoke-direct {v1}, Landroid/webkit/WebViewClient;-><init>()V

    invoke-virtual {v0, v1}, Landroid/webkit/WebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V

    .line 236
    new-instance v1, Landroid/webkit/WebChromeClient;

    invoke-direct {v1}, Landroid/webkit/WebChromeClient;-><init>()V

    invoke-virtual {v0, v1}, Landroid/webkit/WebView;->setWebChromeClient(Landroid/webkit/WebChromeClient;)V

    .line 237
    new-instance v1, Lwww/wslw/cn/JsBridge;

    invoke-direct {v1, p0}, Lwww/wslw/cn/JsBridge;-><init>(Lwww/wslw/cn/MainActivity;)V

    const-string v2, "HG"

    invoke-virtual {v0, v1, v2}, Landroid/webkit/WebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V

    .line 239
    :try_start_0
    new-instance v1, Lwww/wslw/cn/LokiBridge;

    invoke-direct {v1, p0}, Lwww/wslw/cn/LokiBridge;-><init>(Landroid/app/Activity;)V

    const-string v2, "Loki"

    invoke-virtual {v0, v1, v2}, Landroid/webkit/WebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v1

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "LokiBridge fail: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "HGUI"

    invoke-static {v2, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 240
    :goto_0
    invoke-virtual {v0, p1}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V

    return-object v0
.end method

.method private doExitWithConfirm()V
    .locals 9

    .line 323
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    .line 324
    iget-wide v2, p0, Lwww/wslw/cn/MainActivity;->lastBackTime:J

    const-wide/16 v4, 0x0

    cmp-long v6, v2, v4

    if-lez v6, :cond_0

    sub-long v2, v0, v2

    const-wide/16 v6, 0x7d0

    cmp-long v8, v2, v6

    if-gez v8, :cond_0

    .line 325
    iput-wide v4, p0, Lwww/wslw/cn/MainActivity;->lastBackTime:J

    .line 326
    invoke-virtual {p0}, Lwww/wslw/cn/MainActivity;->finish()V

    return-void

    .line 329
    :cond_0
    iput-wide v0, p0, Lwww/wslw/cn/MainActivity;->lastBackTime:J

    .line 331
    :try_start_0
    const-string v0, "\u518d\u6309\u4e00\u6b21\u9000\u51fa\u7a0b\u5e8f"

    const/4 v1, 0x0

    invoke-static {p0, v0, v1}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    return-void
.end method

.method private dp(I)I
    .locals 1

    int-to-float p1, p1

    .line 353
    invoke-virtual {p0}, Lwww/wslw/cn/MainActivity;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    mul-float p1, p1, v0

    const/high16 v0, 0x3f000000    # 0.5f

    add-float/2addr p1, v0

    float-to-int p1, p1

    return p1
.end method

.method private requestLegacyPerms()V
    .locals 7

    .line 247
    :try_start_0
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x17

    if-ge v0, v1, :cond_0

    return-void

    .line 248
    :cond_0
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v1, 0x2

    .line 249
    new-array v2, v1, [Ljava/lang/String;

    const-string v3, "android.permission.READ_EXTERNAL_STORAGE"

    const/4 v4, 0x0

    aput-object v3, v2, v4

    const-string v3, "android.permission.WRITE_EXTERNAL_STORAGE"

    const/4 v5, 0x1

    aput-object v3, v2, v5

    const/4 v3, 0x0

    :goto_0
    if-ge v3, v1, :cond_2

    .line 252
    aget-object v5, v2, v3

    .line 253
    invoke-virtual {p0, v5}, Lwww/wslw/cn/MainActivity;->checkSelfPermission(Ljava/lang/String;)I

    move-result v6

    if-eqz v6, :cond_1

    invoke-interface {v0, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_1
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 255
    :cond_2
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_3

    new-array v1, v4, [Ljava/lang/String;

    invoke-interface {v0, v1}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Ljava/lang/String;

    const/16 v1, 0x3e9

    invoke-virtual {p0, v0, v1}, Lwww/wslw/cn/MainActivity;->requestPermissions([Ljava/lang/String;I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_1

    :catchall_0
    move-exception v0

    .line 257
    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "requestLegacyPerms fail: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "HGUI"

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    :cond_3
    :goto_1
    return-void
.end method

.method private select(I)V
    .locals 4

    const/4 v0, 0x0

    if-ltz p1, :cond_0

    const/4 v1, 0x1

    if-le p1, v1, :cond_1

    :cond_0
    const/4 p1, 0x0

    .line 262
    :cond_1
    iput p1, p0, Lwww/wslw/cn/MainActivity;->cur:I

    const/4 v1, 0x0

    :goto_0
    const/4 v2, 0x3

    if-ge v1, v2, :cond_6

    .line 264
    iget-object v2, p0, Lwww/wslw/cn/MainActivity;->webs:[Landroid/webkit/WebView;

    aget-object v2, v2, v1

    if-nez v2, :cond_2

    goto :goto_4

    :cond_2
    if-ne v1, p1, :cond_3

    const/4 v3, 0x0

    goto :goto_1

    :cond_3
    const/16 v3, 0x8

    .line 265
    :goto_1
    invoke-virtual {v2, v3}, Landroid/webkit/WebView;->setVisibility(I)V

    .line 266
    iget-object v2, p0, Lwww/wslw/cn/MainActivity;->tabLabels:[Landroid/widget/TextView;

    aget-object v2, v2, v1

    if-ne v1, p1, :cond_4

    const/4 v3, -0x1

    goto :goto_2

    :cond_4
    const v3, -0x71716d

    :goto_2
    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setTextColor(I)V

    .line 267
    iget-object v2, p0, Lwww/wslw/cn/MainActivity;->tabBars:[Landroid/view/View;

    aget-object v2, v2, v1

    if-ne v1, p1, :cond_5

    iget-object v3, p0, Lwww/wslw/cn/MainActivity;->accents:[I

    aget v3, v3, v1

    goto :goto_3

    :cond_5
    const/4 v3, 0x0

    :goto_3
    invoke-virtual {v2, v3}, Landroid/view/View;->setBackgroundColor(I)V

    :goto_4
    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_6
    return-void
.end method

.method private setupImmersive(Landroid/view/View;)V
    .locals 1

    .line 128
    invoke-direct {p0}, Lwww/wslw/cn/MainActivity;->applyHideBars()V

    .line 130
    new-instance v0, Lwww/wslw/cn/MainActivity$2;

    invoke-direct {v0, p0, p1}, Lwww/wslw/cn/MainActivity$2;-><init>(Lwww/wslw/cn/MainActivity;Landroid/view/View;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnSystemUiVisibilityChangeListener(Landroid/view/View$OnSystemUiVisibilityChangeListener;)V

    return-void
.end method


# virtual methods
.method public onBackPressed()V
    .locals 3

    .line 292
    iget-object v0, p0, Lwww/wslw/cn/MainActivity;->webs:[Landroid/webkit/WebView;

    iget v1, p0, Lwww/wslw/cn/MainActivity;->cur:I

    aget-object v0, v0, v1

    if-nez v0, :cond_0

    .line 294
    invoke-super {p0}, Landroid/app/Activity;->onBackPressed()V

    return-void

    .line 298
    :cond_0
    :try_start_0
    const-string v1, "(function(){try{return (typeof window.__lokiBack===\'function\')?window.__lokiBack():\'none\';}catch(e){return \'error\';}})()"

    new-instance v2, Lwww/wslw/cn/MainActivity$5;

    invoke-direct {v2, p0, v0}, Lwww/wslw/cn/MainActivity$5;-><init>(Lwww/wslw/cn/MainActivity;Landroid/webkit/WebView;)V

    invoke-virtual {v0, v1, v2}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    nop

    .line 315
    invoke-virtual {v0}, Landroid/webkit/WebView;->canGoBack()Z

    move-result v1

    if-eqz v1, :cond_1

    invoke-virtual {v0}, Landroid/webkit/WebView;->goBack()V

    return-void

    .line 316
    :cond_1
    iget v0, p0, Lwww/wslw/cn/MainActivity;->cur:I

    if-eqz v0, :cond_2

    const/4 v0, 0x0

    invoke-direct {p0, v0}, Lwww/wslw/cn/MainActivity;->select(I)V

    return-void

    .line 317
    :cond_2
    invoke-super {p0}, Landroid/app/Activity;->onBackPressed()V

    :goto_0
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 8

    .line 56
    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    .line 58
    invoke-virtual {p0}, Lwww/wslw/cn/MainActivity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/16 v1, 0x400

    invoke-virtual {v0, v1}, Landroid/view/Window;->addFlags(I)V

    .line 60
    new-instance v0, Landroid/widget/LinearLayout;

    invoke-direct {v0, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    .line 61
    invoke-virtual {v0, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const v2, -0xf4f4f3

    .line 62
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    .line 65
    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct {v3, p0}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x0

    .line 66
    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 67
    invoke-virtual {v3, v2}, Landroid/widget/LinearLayout;->setBackgroundColor(I)V

    .line 68
    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/16 v5, 0x34

    .line 69
    invoke-direct {p0, v5}, Lwww/wslw/cn/MainActivity;->dp(I)I

    move-result v5

    const/4 v6, -0x1

    invoke-direct {v2, v6, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 68
    invoke-virtual {v3, v2}, Landroid/widget/LinearLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 70
    const-string v2, "\u542f\u52a8\u5668"

    invoke-direct {p0, v2, v4}, Lwww/wslw/cn/MainActivity;->buildTab(Ljava/lang/String;I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v3, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 71
    const-string v2, "\u62e6\u622a\u5668"

    invoke-direct {p0, v2, v1}, Lwww/wslw/cn/MainActivity;->buildTab(Ljava/lang/String;I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v3, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    const/4 v7, 0x2

    const-string v2, "\u8bbe\u5907\u6807\u8bc6"

    invoke-direct {p0, v2, v7}, Lwww/wslw/cn/MainActivity;->buildTab(Ljava/lang/String;I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v3, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 72
    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 75
    new-instance v2, Landroid/view/View;

    invoke-direct {v2, p0}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    const v3, -0xe0e0dd

    .line 76
    invoke-virtual {v2, v3}, Landroid/view/View;->setBackgroundColor(I)V

    .line 77
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    .line 78
    invoke-direct {p0, v1}, Lwww/wslw/cn/MainActivity;->dp(I)I

    move-result v5

    invoke-direct {v3, v6, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    .line 77
    invoke-virtual {v2, v3}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 79
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 82
    new-instance v2, Landroid/widget/FrameLayout;

    invoke-direct {v2, p0}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 83
    new-instance v3, Landroid/widget/LinearLayout$LayoutParams;

    const/high16 v5, 0x3f800000    # 1.0f

    invoke-direct {v3, v6, v4, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    invoke-virtual {v2, v3}, Landroid/widget/FrameLayout;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 85
    iget-object v3, p0, Lwww/wslw/cn/MainActivity;->webs:[Landroid/webkit/WebView;

    const-string v5, "http://127.0.0.1:18888/"

    invoke-direct {p0, v5}, Lwww/wslw/cn/MainActivity;->buildWeb(Ljava/lang/String;)Landroid/webkit/WebView;

    move-result-object v5

    aput-object v5, v3, v4

    .line 86
    iget-object v3, p0, Lwww/wslw/cn/MainActivity;->webs:[Landroid/webkit/WebView;

    const-string v5, "http://127.0.0.1:16666/"

    invoke-direct {p0, v5}, Lwww/wslw/cn/MainActivity;->buildWeb(Ljava/lang/String;)Landroid/webkit/WebView;

    move-result-object v5

    aput-object v5, v3, v1

    iget-object v3, p0, Lwww/wslw/cn/MainActivity;->webs:[Landroid/webkit/WebView;

    const-string v5, "http://127.0.0.1:16667/"

    invoke-direct {p0, v5}, Lwww/wslw/cn/MainActivity;->buildWeb(Ljava/lang/String;)Landroid/webkit/WebView;

    move-result-object v5

    aput-object v5, v3, v7

    .line 87
    iget-object v3, p0, Lwww/wslw/cn/MainActivity;->webs:[Landroid/webkit/WebView;

    aget-object v3, v3, v4

    invoke-virtual {v2, v3}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;)V

    .line 88
    iget-object v3, p0, Lwww/wslw/cn/MainActivity;->webs:[Landroid/webkit/WebView;

    aget-object v1, v3, v1

    invoke-virtual {v2, v1}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;)V

    aget-object v3, v3, v7

    invoke-virtual {v2, v3}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;)V

    .line 89
    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 94
    new-instance v1, Lwww/wslw/cn/MainActivity$1;

    invoke-direct {v1, p0}, Lwww/wslw/cn/MainActivity$1;-><init>(Lwww/wslw/cn/MainActivity;)V

    invoke-virtual {v2, v1}, Landroid/widget/FrameLayout;->setOnApplyWindowInsetsListener(Landroid/view/View$OnApplyWindowInsetsListener;)V

    .line 115
    invoke-virtual {p0, v0}, Lwww/wslw/cn/MainActivity;->setContentView(Landroid/view/View;)V

    .line 116
    invoke-direct {p0, v0}, Lwww/wslw/cn/MainActivity;->setupImmersive(Landroid/view/View;)V

    .line 117
    invoke-direct {p0}, Lwww/wslw/cn/MainActivity;->requestLegacyPerms()V

    if-eqz p1, :cond_0

    .line 118
    const-string v0, "tab"

    invoke-virtual {p1, v0, v4}, Landroid/os/Bundle;->getInt(Ljava/lang/String;I)I

    move-result v4

    .line 119
    :cond_0
    invoke-direct {p0, v4}, Lwww/wslw/cn/MainActivity;->select(I)V

    return-void
.end method

.method protected onDestroy()V
    .locals 3

    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x3

    if-ge v0, v1, :cond_1

    .line 344
    iget-object v1, p0, Lwww/wslw/cn/MainActivity;->webs:[Landroid/webkit/WebView;

    aget-object v1, v1, v0

    if-eqz v1, :cond_0

    .line 345
    invoke-virtual {v1}, Landroid/webkit/WebView;->destroy()V

    .line 346
    iget-object v1, p0, Lwww/wslw/cn/MainActivity;->webs:[Landroid/webkit/WebView;

    const/4 v2, 0x0

    aput-object v2, v1, v0

    :cond_0
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    .line 349
    :cond_1
    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    return-void
.end method

.method protected onSaveInstanceState(Landroid/os/Bundle;)V
    .locals 2

    .line 337
    invoke-super {p0, p1}, Landroid/app/Activity;->onSaveInstanceState(Landroid/os/Bundle;)V

    .line 338
    const-string v0, "tab"

    iget v1, p0, Lwww/wslw/cn/MainActivity;->cur:I

    invoke-virtual {p1, v0, v1}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    return-void
.end method

.method public onWindowFocusChanged(Z)V
    .locals 0

    .line 175
    invoke-super {p0, p1}, Landroid/app/Activity;->onWindowFocusChanged(Z)V

    if-eqz p1, :cond_0

    .line 176
    invoke-direct {p0}, Lwww/wslw/cn/MainActivity;->applyHideBars()V

    :cond_0
    return-void
.end method

.method switchTabFromJs(I)V
    .locals 1

    .line 272
    new-instance v0, Lwww/wslw/cn/MainActivity$4;

    invoke-direct {v0, p0, p1}, Lwww/wslw/cn/MainActivity$4;-><init>(Lwww/wslw/cn/MainActivity;I)V

    invoke-virtual {p0, v0}, Lwww/wslw/cn/MainActivity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void
.end method
