.class Lwww/wslw/cn/MainActivity$3;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lwww/wslw/cn/MainActivity;->buildTab(Ljava/lang/String;I)Landroid/view/View;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lwww/wslw/cn/MainActivity;

.field final synthetic val$idx:I


# direct methods
.method constructor <init>(Lwww/wslw/cn/MainActivity;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 204
    iput-object p1, p0, Lwww/wslw/cn/MainActivity$3;->this$0:Lwww/wslw/cn/MainActivity;

    iput p2, p0, Lwww/wslw/cn/MainActivity$3;->val$idx:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 1

    .line 206
    iget-object p1, p0, Lwww/wslw/cn/MainActivity$3;->this$0:Lwww/wslw/cn/MainActivity;

    iget v0, p0, Lwww/wslw/cn/MainActivity$3;->val$idx:I

    invoke-static {p1, v0}, Lwww/wslw/cn/MainActivity;->access$100(Lwww/wslw/cn/MainActivity;I)V

    return-void
.end method
