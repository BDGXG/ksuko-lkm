.class Lwww/wslw/cn/MainActivity$4;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lwww/wslw/cn/MainActivity;->switchTabFromJs(I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lwww/wslw/cn/MainActivity;

.field final synthetic val$i:I


# direct methods
.method constructor <init>(Lwww/wslw/cn/MainActivity;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 272
    iput-object p1, p0, Lwww/wslw/cn/MainActivity$4;->this$0:Lwww/wslw/cn/MainActivity;

    iput p2, p0, Lwww/wslw/cn/MainActivity$4;->val$i:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 2

    .line 274
    iget-object v0, p0, Lwww/wslw/cn/MainActivity$4;->this$0:Lwww/wslw/cn/MainActivity;

    iget v1, p0, Lwww/wslw/cn/MainActivity$4;->val$i:I

    invoke-static {v0, v1}, Lwww/wslw/cn/MainActivity;->access$100(Lwww/wslw/cn/MainActivity;I)V

    return-void
.end method
