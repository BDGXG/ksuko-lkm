.class Lwww/wslw/cn/JsBridge$2;
.super Ljava/lang/Object;
.source "JsBridge.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lwww/wslw/cn/JsBridge;->paste()Ljava/lang/String;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lwww/wslw/cn/JsBridge;

.field final synthetic val$latch:Ljava/util/concurrent/CountDownLatch;

.field final synthetic val$out:[Ljava/lang/String;


# direct methods
.method constructor <init>(Lwww/wslw/cn/JsBridge;[Ljava/lang/String;Ljava/util/concurrent/CountDownLatch;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 111
    iput-object p1, p0, Lwww/wslw/cn/JsBridge$2;->this$0:Lwww/wslw/cn/JsBridge;

    iput-object p2, p0, Lwww/wslw/cn/JsBridge$2;->val$out:[Ljava/lang/String;

    iput-object p3, p0, Lwww/wslw/cn/JsBridge$2;->val$latch:Ljava/util/concurrent/CountDownLatch;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 114
    :try_start_0
    iget-object v0, p0, Lwww/wslw/cn/JsBridge$2;->this$0:Lwww/wslw/cn/JsBridge;

    .line 115
    invoke-static {v0}, Lwww/wslw/cn/JsBridge;->access$000(Lwww/wslw/cn/JsBridge;)Lwww/wslw/cn/MainActivity;

    move-result-object v0

    const-string v1, "clipboard"

    invoke-virtual {v0, v1}, Lwww/wslw/cn/MainActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/ClipboardManager;

    if-eqz v0, :cond_0

    .line 116
    invoke-virtual {v0}, Landroid/content/ClipboardManager;->hasPrimaryClip()Z

    move-result v1

    if-eqz v1, :cond_0

    .line 117
    invoke-virtual {v0}, Landroid/content/ClipboardManager;->getPrimaryClip()Landroid/content/ClipData;

    move-result-object v1

    if-eqz v1, :cond_0

    .line 118
    invoke-virtual {v0}, Landroid/content/ClipboardManager;->getPrimaryClip()Landroid/content/ClipData;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/ClipData;->getItemCount()I

    move-result v1

    if-lez v1, :cond_0

    .line 119
    invoke-virtual {v0}, Landroid/content/ClipboardManager;->getPrimaryClip()Landroid/content/ClipData;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/content/ClipData;->getItemAt(I)Landroid/content/ClipData$Item;

    move-result-object v0

    iget-object v2, p0, Lwww/wslw/cn/JsBridge$2;->this$0:Lwww/wslw/cn/JsBridge;

    invoke-static {v2}, Lwww/wslw/cn/JsBridge;->access$000(Lwww/wslw/cn/JsBridge;)Lwww/wslw/cn/MainActivity;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/content/ClipData$Item;->coerceToText(Landroid/content/Context;)Ljava/lang/CharSequence;

    move-result-object v0

    if-eqz v0, :cond_0

    .line 120
    iget-object v2, p0, Lwww/wslw/cn/JsBridge$2;->val$out:[Ljava/lang/String;

    invoke-interface {v0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v0

    aput-object v0, v2, v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 125
    :catchall_0
    :cond_0
    iget-object v0, p0, Lwww/wslw/cn/JsBridge$2;->val$latch:Ljava/util/concurrent/CountDownLatch;

    invoke-virtual {v0}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    return-void
.end method
