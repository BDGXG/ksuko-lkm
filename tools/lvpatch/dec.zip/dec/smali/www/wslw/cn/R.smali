.class public final Lwww/wslw/cn/R;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lwww/wslw/cn/R$style;,
        Lwww/wslw/cn/R$string;,
        Lwww/wslw/cn/R$mipmap;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 0

    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
