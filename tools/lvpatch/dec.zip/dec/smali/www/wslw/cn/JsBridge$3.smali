.class Lwww/wslw/cn/JsBridge$3;
.super Ljava/lang/Object;
.source "JsBridge.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lwww/wslw/cn/JsBridge;->toast(Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lwww/wslw/cn/JsBridge;

.field final synthetic val$msg:Ljava/lang/String;


# direct methods
.method constructor <init>(Lwww/wslw/cn/JsBridge;Ljava/lang/String;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 139
    iput-object p1, p0, Lwww/wslw/cn/JsBridge$3;->this$0:Lwww/wslw/cn/JsBridge;

    iput-object p2, p0, Lwww/wslw/cn/JsBridge$3;->val$msg:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 3

    .line 141
    iget-object v0, p0, Lwww/wslw/cn/JsBridge$3;->this$0:Lwww/wslw/cn/JsBridge;

    invoke-static {v0}, Lwww/wslw/cn/JsBridge;->access$000(Lwww/wslw/cn/JsBridge;)Lwww/wslw/cn/MainActivity;

    move-result-object v0

    iget-object v1, p0, Lwww/wslw/cn/JsBridge$3;->val$msg:Ljava/lang/String;

    const/4 v2, 0x0

    invoke-static {v0, v1, v2}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object v0

    invoke-virtual {v0}, Landroid/widget/Toast;->show()V

    return-void
.end method
