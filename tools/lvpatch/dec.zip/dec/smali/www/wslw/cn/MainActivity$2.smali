.class Lwww/wslw/cn/MainActivity$2;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/view/View$OnSystemUiVisibilityChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lwww/wslw/cn/MainActivity;->setupImmersive(Landroid/view/View;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lwww/wslw/cn/MainActivity;

.field final synthetic val$root:Landroid/view/View;


# direct methods
.method constructor <init>(Lwww/wslw/cn/MainActivity;Landroid/view/View;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 130
    iput-object p1, p0, Lwww/wslw/cn/MainActivity$2;->this$0:Lwww/wslw/cn/MainActivity;

    iput-object p2, p0, Lwww/wslw/cn/MainActivity$2;->val$root:Landroid/view/View;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onSystemUiVisibilityChange(I)V
    .locals 3

    and-int/lit8 p1, p1, 0x2

    if-nez p1, :cond_0

    .line 133
    iget-object p1, p0, Lwww/wslw/cn/MainActivity$2;->val$root:Landroid/view/View;

    new-instance v0, Lwww/wslw/cn/MainActivity$2$1;

    invoke-direct {v0, p0}, Lwww/wslw/cn/MainActivity$2$1;-><init>(Lwww/wslw/cn/MainActivity$2;)V

    const-wide/16 v1, 0x4b0

    invoke-virtual {p1, v0, v1, v2}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_0
    return-void
.end method
