.class Lwww/wslw/cn/MainActivity$2$1;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lwww/wslw/cn/MainActivity$2;->onSystemUiVisibilityChange(I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$1:Lwww/wslw/cn/MainActivity$2;


# direct methods
.method constructor <init>(Lwww/wslw/cn/MainActivity$2;)V
    .locals 0

    .line 133
    iput-object p1, p0, Lwww/wslw/cn/MainActivity$2$1;->this$1:Lwww/wslw/cn/MainActivity$2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 1

    .line 134
    iget-object v0, p0, Lwww/wslw/cn/MainActivity$2$1;->this$1:Lwww/wslw/cn/MainActivity$2;

    iget-object v0, v0, Lwww/wslw/cn/MainActivity$2;->this$0:Lwww/wslw/cn/MainActivity;

    invoke-static {v0}, Lwww/wslw/cn/MainActivity;->access$000(Lwww/wslw/cn/MainActivity;)V

    return-void
.end method
