.class Lwww/wslw/cn/LokiBridge$1;
.super Ljava/lang/Object;
.source "LokiBridge.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lwww/wslw/cn/LokiBridge;->getAllAppIconsAsync()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lwww/wslw/cn/LokiBridge;


# direct methods
.method constructor <init>(Lwww/wslw/cn/LokiBridge;)V
    .locals 0

    .line 160
    iput-object p1, p0, Lwww/wslw/cn/LokiBridge$1;->this$0:Lwww/wslw/cn/LokiBridge;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .locals 8

    const/4 v0, 0x0

    .line 163
    :try_start_0
    iget-object v1, p0, Lwww/wslw/cn/LokiBridge$1;->this$0:Lwww/wslw/cn/LokiBridge;

    invoke-static {v1}, Lwww/wslw/cn/LokiBridge;->access$000(Lwww/wslw/cn/LokiBridge;)Landroid/app/Activity;

    move-result-object v1

    invoke-virtual {v1}, Landroid/app/Activity;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    .line 164
    invoke-virtual {v1, v0}, Landroid/content/pm/PackageManager;->getInstalledApplications(I)Ljava/util/List;

    move-result-object v2

    const/4 v3, 0x0

    .line 165
    :goto_0
    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v4
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    if-ge v3, v4, :cond_3

    .line 167
    :try_start_1
    invoke-interface {v2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/content/pm/ApplicationInfo;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    if-nez v4, :cond_0

    goto :goto_1

    .line 169
    :cond_0
    :try_start_2
    iget-object v5, v4, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    .line 170
    iget-object v6, p0, Lwww/wslw/cn/LokiBridge$1;->this$0:Lwww/wslw/cn/LokiBridge;

    invoke-static {v6}, Lwww/wslw/cn/LokiBridge;->access$100(Lwww/wslw/cn/LokiBridge;)Ljava/util/Map;

    move-result-object v6

    invoke-interface {v6, v5}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v6
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    if-eqz v6, :cond_1

    goto :goto_1

    .line 172
    :cond_1
    :try_start_3
    iget-object v6, p0, Lwww/wslw/cn/LokiBridge$1;->this$0:Lwww/wslw/cn/LokiBridge;

    invoke-virtual {v4, v1}, Landroid/content/pm/ApplicationInfo;->loadIcon(Landroid/content/pm/PackageManager;)Landroid/graphics/drawable/Drawable;

    move-result-object v4

    const/16 v7, 0x60

    invoke-static {v6, v4, v7}, Lwww/wslw/cn/LokiBridge;->access$200(Lwww/wslw/cn/LokiBridge;Landroid/graphics/drawable/Drawable;I)Ljava/lang/String;

    move-result-object v4

    if-eqz v4, :cond_2

    .line 173
    iget-object v6, p0, Lwww/wslw/cn/LokiBridge$1;->this$0:Lwww/wslw/cn/LokiBridge;

    invoke-static {v6}, Lwww/wslw/cn/LokiBridge;->access$100(Lwww/wslw/cn/LokiBridge;)Ljava/util/Map;

    move-result-object v6

    invoke-interface {v6, v5, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :catchall_0
    :cond_2
    :goto_1
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 177
    :catchall_1
    :cond_3
    iget-object v1, p0, Lwww/wslw/cn/LokiBridge$1;->this$0:Lwww/wslw/cn/LokiBridge;

    const/4 v2, 0x1

    invoke-static {v1, v2}, Lwww/wslw/cn/LokiBridge;->access$302(Lwww/wslw/cn/LokiBridge;Z)Z

    .line 178
    iget-object v1, p0, Lwww/wslw/cn/LokiBridge$1;->this$0:Lwww/wslw/cn/LokiBridge;

    invoke-static {v1, v0}, Lwww/wslw/cn/LokiBridge;->access$402(Lwww/wslw/cn/LokiBridge;Z)Z

    return-void
.end method
